package com.liveasy.loadapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.liveasy.loadapi.model.Load;
import com.liveasy.loadapi.service.LoadService;

@RestController
@RequestMapping("/load")
public class LoadController {
    @Autowired
    private LoadService loadService;

    @PostMapping
    public ResponseEntity<Load> createLoad(@RequestBody Load load) {
        Load savedLoad = loadService.saveLoad(load);
        return new ResponseEntity<>(savedLoad, HttpStatus.CREATED);
    }

    @GetMapping
    public List<Load> getLoads() {
        return loadService.getLoads();
    }
    
    @GetMapping("/ShipperId/{ShipperId}")
    public List<Load> getLoadsByShipperId(@PathVariable String ShipperId) {
    	return loadService.getLoadsByShipperId(ShipperId);
    }

    @GetMapping("/loadId/{loadId}")
    public Load getLoad(@PathVariable String loadId) {
        return loadService.getLoadById(loadId);
    }

    @PutMapping("/{loadId}")
    public Load updateLoad(@PathVariable String loadId, @RequestBody Load load) {
        return loadService.updateLoad(loadId, load);
    }

    @DeleteMapping("/{loadId}")
    public ResponseEntity<Void> deleteLoad(@PathVariable String loadId) {
        loadService.deleteLoad(loadId);
        return ResponseEntity.noContent().build();
    }
}
