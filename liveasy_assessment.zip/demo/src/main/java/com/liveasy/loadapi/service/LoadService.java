package com.liveasy.loadapi.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.liveasy.loadapi.model.Load;
import com.liveasy.loadapi.repository.LoadRepository;

@Service
public class LoadService {

    @Autowired
    private LoadRepository loadRepository;

    // Save a new Load
    public Load saveLoad(Load load) {
        return loadRepository.save(load);
    }

    // Get all Loads
    public List<Load> getLoads() {
        return loadRepository.findAll();
    }

    // Get Loads by ShipperId
    public List<Load> getLoadsByShipperId(String shipperId) {
        return loadRepository.findAll()
                .stream()
                .filter(load -> shipperId.equals(load.getShipperId()))
                .collect(Collectors.toList());
    }


    // Get Load by LoadId
    public Load getLoadById(String loadId) {
        return loadRepository.findById(loadId)
                .orElseThrow(() -> new RuntimeException("Load not found with id: " + loadId));
    }

    // Update Load details
    public Load updateLoad(String loadId, Load updatedLoad) {
        Load existingLoad = getLoadById(loadId);
        existingLoad.setProductType(updatedLoad.getProductType());
        existingLoad.setTruckType(updatedLoad.getTruckType());
        existingLoad.setNoOfTrucks(updatedLoad.getNoOfTrucks());
        existingLoad.setWeight(updatedLoad.getWeight());
        existingLoad.setComment(updatedLoad.getComment());
        existingLoad.setShipperId(updatedLoad.getShipperId());
        existingLoad.setDate(updatedLoad.getDate());
        return loadRepository.save(existingLoad);
    }

    // Delete Load by LoadId
    public void deleteLoad(String loadId) {
        if (!loadRepository.existsById(loadId)) {
            throw new RuntimeException("Load not found with id: " + loadId);
        }
        loadRepository.deleteById(loadId);
    }
}
